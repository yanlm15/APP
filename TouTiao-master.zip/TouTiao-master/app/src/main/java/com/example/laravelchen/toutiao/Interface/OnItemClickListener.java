package com.example.laravelchen.toutiao.Interface;

import android.view.View;

/**
 * Created by LaravelChen on 2017/6/12.
 */

public interface OnItemClickListener {
    void onClick(View view, int position);
}
